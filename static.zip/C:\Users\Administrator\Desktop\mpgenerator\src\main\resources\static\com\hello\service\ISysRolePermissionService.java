package com.hello.service;

import com.hello.entity.SysRolePermission;
import com.hello.base.BaseService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author yangnian123
 * @since 2018-09-02
 */
public interface ISysRolePermissionService extends BaseService<SysRolePermission> {



}
