package com.hello.service;

import com.hello.entity.SysRoles;
import com.hello.base.BaseService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author yangnian123
 * @since 2018-09-02
 */
public interface ISysRolesService extends BaseService<SysRoles> {



}
